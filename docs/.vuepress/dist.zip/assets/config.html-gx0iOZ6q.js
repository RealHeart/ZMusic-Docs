import{_ as e}from"./plugin-vue_export-helper-DlAUqK2U.js";import{r as t,o,c as p,a as n,b as s,d as l,e as i}from"./app-DknmCEgY.js";const c={},r={href:"https://toml.io/cn/",target:"_blank",rel:"noopener noreferrer"},m=i(`<div class="language-toml line-numbers-mode" data-ext="toml" data-title="toml"><pre class="language-toml"><code><span class="token comment"># 是否开启调试模式</span>
<span class="token key property">debug</span> <span class="token punctuation">=</span> <span class="token boolean">false</span>
<span class="token comment"># 是否检查更新</span>
<span class="token key property">check-update</span> <span class="token punctuation">=</span> <span class="token boolean">true</span>
<span class="token comment"># 插件使用的语言</span>
<span class="token comment"># 支持的语言:</span>
<span class="token comment"># auto: 自动检测 (默认)</span>
<span class="token comment"># en-US: English</span>
<span class="token comment"># zh-CN: 简体中文</span>
<span class="token key property">language</span> <span class="token punctuation">=</span> <span class="token string">&quot;auto&quot;</span>
<span class="token comment"># 消息前缀</span>
<span class="token key property">prefix</span> <span class="token punctuation">=</span> <span class="token string">&quot;&amp;bZMusic &amp;e&gt;&gt;&gt; &amp;r&quot;</span>

<span class="token comment"># API设置</span>
<span class="token punctuation">[</span><span class="token table class-name">api</span><span class="token punctuation">]</span>
<span class="token comment"># 网易云音乐</span>
<span class="token key property">netease-link</span> <span class="token punctuation">=</span> <span class="token string">&quot;https://zm.armoe.cn&quot;</span>

<span class="token comment"># ZMusic VIP设置</span>
<span class="token punctuation">[</span><span class="token table class-name">vip</span><span class="token punctuation">]</span>
<span class="token comment"># 授权QQ</span>
<span class="token key property">qq</span> <span class="token punctuation">=</span> <span class="token string">&quot;&quot;</span>
<span class="token comment"># 授权Key</span>
<span class="token key property">key</span> <span class="token punctuation">=</span> <span class="token string">&quot;&quot;</span>

<span class="token comment"># 代理设置</span>
<span class="token punctuation">[</span><span class="token table class-name">proxy</span><span class="token punctuation">]</span>
<span class="token comment"># 是否启用代理</span>
<span class="token key property">enable</span> <span class="token punctuation">=</span> <span class="token boolean">false</span>
<span class="token comment"># 代理类型 HTTP/SOCKS</span>
<span class="token key property">type</span> <span class="token punctuation">=</span> <span class="token string">&quot;HTTP&quot;</span>
<span class="token comment"># 主机名</span>
<span class="token key property">hostname</span> <span class="token punctuation">=</span> <span class="token string">&quot;127.0.0.1&quot;</span>
<span class="token comment"># 端口</span>
<span class="token key property">port</span> <span class="token punctuation">=</span> <span class="token number">8080</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div>`,1);function u(d,k){const a=t("ExternalLinkIcon");return o(),p("div",null,[n("p",null,[s("TOML 规范说明请参考 "),n("a",r,[s("toml.io"),l(a)])]),m])}const g=e(c,[["render",u],["__file","config.html.vue"]]),y=JSON.parse('{"path":"/guide/config.html","title":"配置文件","lang":"zh-CN","frontmatter":{"title":"配置文件","icon":"fa-solid fa-gear"},"headers":[],"git":{"createdTime":1707848305000,"updatedTime":1707848305000,"contributors":[{"name":"真心","email":"qgzhenxin@qq.com","commits":1}]},"readingTime":{"minutes":0.45,"words":134},"filePathRelative":"guide/config.md","localizedDate":"2024年2月14日"}');export{g as comp,y as data};
